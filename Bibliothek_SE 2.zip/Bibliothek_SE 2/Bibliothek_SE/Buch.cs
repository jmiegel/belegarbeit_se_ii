﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliothek_SE
{
    public class Buch
    {
        public Buch(string Signatur_ID, string Titel, string Autor, bool ExemplarTyp, string Vorgemerkt)
        {
            this.Signatur_ID = Signatur_ID;
            this.Titel = Titel;
            this.Autor = Autor;
            this.ExemplarTyp = ExemplarTyp;
            this.Vorgemerkt = Vorgemerkt;
        }
        public string Signatur_ID     //Signatur nötig um Buch eindeutig zu identifizieren
        {
            get;
            set;
        }
        public string Autor     
        {
            get;
            set;
        }
        public string Titel     
        {
            get;
            set;
        }
        public bool ExemplarTyp
        {
            get;
            set;
        }
        public string Vorgemerkt
        {
            get;
            set;
        }

        public string BuchDetails {
            get
            {
                string details = Autor+ " " + Titel + " " + ExemplarTyp + " " + Vorgemerkt ;
                return details;
            }
        }

    }
}
