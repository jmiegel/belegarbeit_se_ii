﻿using System;
using System.Data.Odbc;
using System.Collections.Generic;

namespace Beleg.DBConnection
{
    public class DBConnection
    {
        private OdbcConnection connection;
        public DBConnection()
        {
            connection = new OdbcConnection();
            connection.ConnectionString =
            "Driver={SQL Server};" +
            "Server=141.56.2.45,1433;" +
            "Uid=s75913;" +
            "Pwd=s75913;";
	    }

        public List<BibliotheksNutzer> getUser()
        {
            List<BibliotheksNutzer> bibliotheksNutzer = new List<BibliotheksNutzer>();
            string SQLQuery = "SELECT";
        }
    }
}