﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bibliothek_SE
{
    public partial class Form1 : Form
    {

        DataBConnection dbConnection = new DataBConnection();
        public Form1()
        {
            InitializeComponent();
            listView1.View = View.Details;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        //Nach Entwurf
        private void buttonNutzerID_Click(object sender, EventArgs e)
        {
            bool doesUserExists = false;
            if (string.IsNullOrWhiteSpace(textBoxNutzerID.Text))
                MessageBox.Show("Bitte geben Sie eine NutzerID ein.", "NutzerID nötig!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            listView1.Items.Clear();
            List<String> signaturList = new List<string>();
            List<String> lentBooksTitleList = new List<string>();

            foreach (var lentItem in dbConnection.getLentFromData()) {
                if (textBoxNutzerID.Text.Equals(lentItem.Nutzer_ID))
                {
                    doesUserExists = true;
                    foreach (var bookItem in dbConnection.getBooksFromData()){
                        if (lentItem.Signatur_ID == bookItem.Signatur_ID)
                            listView1.Items.Add(new ListViewItem(new string[] { bookItem.Signatur_ID, bookItem.Titel, bookItem.Autor, lentItem.Datum.ToString() }));
                    }
                }
            }
            
            if (listView1.Items.Count == 0 && !string.IsNullOrWhiteSpace(textBoxNutzerID.Text) && doesUserExists)
                MessageBox.Show("Keine Einträge gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            else if (!doesUserExists)
                MessageBox.Show("Keine Nutzer mit dieser Nutzer_ID gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 

        }

        //Nach Entwurf
        private void buttonSignatur_Click(object sender, EventArgs e)
        {
            bool doesBookExist = false;
            if (string.IsNullOrWhiteSpace(textBoxSignatur.Text))
            {
                MessageBox.Show("Bitte geben Sie eine Signatur ein.","Signatur fehlt!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else
            {
                foreach (var bookItem in dbConnection.getBooksFromData())
                {
                    if (textBoxSignatur.Text.Equals(bookItem.Signatur_ID))
                    {
                        labelAutorAuswahl.Text = bookItem.Autor.ToString();
                        labelTitelAuswahl.Text = bookItem.Titel.ToString();
                        doesBookExist = true;
                    }
                }
                if (!doesBookExist)
                    MessageBox.Show("Keine Einträge gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
        }

        private void buttonAusleihen_Click(object sender, EventArgs e)
        {
            bool nutzerExists = false;
            //Falls die textBoxen leer sind
            if(string.IsNullOrWhiteSpace(textBoxSignatur.Text) || string.IsNullOrWhiteSpace(textBoxNutzerID.Text)){
                MessageBox.Show("Bitte geben Sie eine NutzerID und eine Signatur ein.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else{
                //Holt sich die Liste von Nutzern aus der Datenbank
                foreach(var userItem in dbConnection.getUserFromData()){
                    //Falls Nutzer existiert
                    if (textBoxNutzerID.Text.Equals(userItem.Nutzer_ID)){
                        nutzerExists = true;
                        //Falls Nuter eine Mahnung hat
                        MessageBox.Show(userItem.MahnungVorhanden.ToString() + " -> test", "another test", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        if (userItem.MahnungVorhanden.ToString().Equals("True"))
                        {
                            MessageBox.Show("Dieser Nutzer darf keine Bücher ausleihen: Mahnung vorhanden.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            break;
                        }
                        //Vergleich des Ablaufdatums mit dem jetzigen Tag < 0 ist noch im Datum, = ist gleicher Tag, > 0 ist nach dem Tag der Abfrage
                        else if (DateTime.Compare(userItem.AblaufDatum, DateTime.Today) < 0)
                        {
                            MessageBox.Show("Dieser Nutzer hat keinen gültigen Ausweis mehr: Warnung vorhanden.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            break;
                        }
                        //Wenn keine Mahnung/AblaufDatum noch in Zukunft liegt
                        else
                        {
                            foreach (var bookItem in dbConnection.getBooksFromData())
                            {
                                //Buch ist ein Ausleihexemplar
                                if (bookItem.ExemplarTyp.ToString().Equals("1"))
                                {
                                    MessageBox.Show("Dieses Buch ist ein exemplar Typ und somit nicht zum Ausleihen verfügbar.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    break;
                                }
                                //Buch ist vorgemerkt
                                else if (!bookItem.Vorgemerkt.ToString().Equals("NULL"))
                                {
                                    MessageBox.Show("Dieses Buch ist vorgemerkt und somit nicht zum Ausleihen verfügbar.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    break;
                                }
                                else
                                {
                                    bool bookCanBeBorrowed = false;
                                    //Holt sich die ganze Ausleihliste
                                    foreach (var lentItem in dbConnection.getLentFromData())
                                    {
                                        if (lentItem.Signatur_ID.Equals(textBoxSignatur.Text))
                                        {
                                            MessageBox.Show("Diese Buch ist schon ausgeliehen und somit nicht zum Ausleihen verfügbar.", "Ausleihen fegeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                            break;
                                        }
                                        else
                                            bookCanBeBorrowed = true;
                                        //Buch ist nicht vorgemerkt, es liegt keine Mahnung vor, Ablaufdatum liegt in der Zukunft
                                    }
                                    if (!bookCanBeBorrowed)
                                    {
                                        //Aushleihen von Bücher
                                        dbConnection.lendBook(textBoxNutzerID.Text, textBoxSignatur.Text);
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
                if (!nutzerExists)
                    MessageBox.Show("Dieser Nutzer existiert nicht: Warnung vorhanden.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonRueckgabe_Click(object sender, EventArgs e)
        {
            bool booksReturned = false;
            int i = 0;
                
            for (i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Checked == true)
                {
                    dbConnection.returnBook(listView1.Items[i].Text);
                    booksReturned = true;
                }
            }

            if (booksReturned)
            {
                MessageBox.Show("Einträge erfolgreich gelöscht.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                buttonNutzerID_Click(sender, e);
            }
            else
                MessageBox.Show("Kein Eintrag ausgewählt/gefunden.", "Zurückgeben fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void buttonVerlaengern_Click(object sender, EventArgs e)
        {
            bool booksExtended = false;
            int i = 0;
            for (i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Checked == true)
                {
                    dbConnection.extendBook(listView1.Items[i].Text);
                    booksExtended = true;
                }
            }
            if (booksExtended)
            {
                MessageBox.Show("Einträge erfolgreich verlängert.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                buttonNutzerID_Click(sender, e);
            }
            else
                MessageBox.Show("Kein Eintrag ausgewählt/gefunden.", "Zurückgeben fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }
    }
}
