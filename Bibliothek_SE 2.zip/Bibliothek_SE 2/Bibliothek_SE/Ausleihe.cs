﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliothek_SE
{
    public class Ausleihe
    {
        public Ausleihe(string Nutzer_ID, string Signatur_ID, DateTime Datum)
        {
            this.Nutzer_ID = Nutzer_ID;
            this.Signatur_ID = Signatur_ID;
            this.Datum = Datum;
        }
        public string Nutzer_ID
        {
            get;
            private set;
        }
        public string Signatur_ID
        {
            get;
            private set;
        }
        public DateTime Datum
        {
            get;
            private set;
        }
        
        
    }
}
