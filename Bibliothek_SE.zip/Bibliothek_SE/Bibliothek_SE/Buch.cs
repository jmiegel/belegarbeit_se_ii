﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliothek_SE
{
    class Buch
    {
        public string Signatur_ID     //Signatur nötig um Buch eindeutig zu identifizieren
        {
            get;
            set;
        }
        public string Autor     
        {
            get;
            set;
        }
        public string Titel     
        {
            get;
            set;
        }
        public bool ExemplarTyp
        {
            get;
            set;
        }
        public bool Vorgemerkt
        {
            get;
            set;
        }

        public string BuchDetails {
            get
            {
                string details = Autor+ " " + Titel + " " + ExemplarTyp + " " + Vorgemerkt ;
                return details;
            }
        }
    }
}
