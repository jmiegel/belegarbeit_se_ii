﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliothek_SE
{
    class Ausleihe
    {
        public string Ausleihe_ID     //Ausleih ID nötig um Nutzer und jeweilig ausgeliehendes Buch eindeutig zu identifizieren
        {
            get;
            private set;
        }
        public DateTime Datum
        {
            get;
            private set;
        }
    }
}
