﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace Bibliothek_SE
{
    public class DataBConnection
    {
        public string connectionString = "Data Source=idb45;Initial Catalog=ii16s75905;Integrated Security=True";
        
        public void CnnVal(string name)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            if (connection.State == System.Data.ConnectionState.Open)
            {
                String q = "SELECT * FROM AUSLEIHE";
                SqlCommand cmd = new SqlCommand(q, connection);
                MessageBox.Show("Connection made Success");
            }
        }

        /*public List<Nutzer> GetUser(string NutzerID) {
            //throw new NotImplementedException();
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.ConnectionValue("SampleDB"))) {
                
                //connection.Query<Nutzer>("SELECT * FROM bibliotheksNutzer where='{0}'", NutzerID).ToList();
                //return put;
            }

        }//*/

    }
}
