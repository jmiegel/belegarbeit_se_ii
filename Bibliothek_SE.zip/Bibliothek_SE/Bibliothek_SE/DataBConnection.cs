﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace Bibliothek_SE
{
    public class DataBConnection
    {
        private string connectionString = "Data Source=idb45;Initial Catalog=ii16s75913;Integrated Security=True";
        
        
        public bool connectToDB()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            if (connection.State == System.Data.ConnectionState.Open) { return true; }
            else { return false; }
        }

        public List<Buch> getBooksFromData() {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            List<Buch> books = new List<Buch>();
            if (connection.State == System.Data.ConnectionState.Open)
            {
                bool exTyp = false;
                string q = "SELECT * FROM bibliotheksBuch";
                SqlCommand cmd = new SqlCommand(q, connection);
                cmd.ExecuteNonQuery();
                cmd.CommandType = System.Data.CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    if (rdr[3].ToString().Contains("1"))
                        exTyp = true;
                    books.Add(new Buch(rdr[0].ToString(), rdr[1].ToString(), rdr[2].ToString(), exTyp, rdr[4].ToString()));
                }
                
            }
            return books;
        }

        public List<Nutzer> getUserFromData() {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            List<Nutzer> user = new List<Nutzer>();
            if (connection.State == System.Data.ConnectionState.Open)
            {
                bool mahnungVorhanden = false;
                string q = "SELECT * FROM bibliotheksNutzer";
                DateTime dateTime;
                SqlCommand cmd = new SqlCommand(q, connection);
                cmd.ExecuteNonQuery();
                cmd.CommandType = System.Data.CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    if (rdr[2].ToString().Contains("1"))
                        mahnungVorhanden = true;
                    dateTime = DateTime.Parse(rdr[1].ToString());
                    user.Add(new Nutzer(rdr[0].ToString(), dateTime,mahnungVorhanden));
                }
            }
            return user;
        }

        public List<Ausleihe> getLentFromData()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            List<Ausleihe> lent = new List<Ausleihe>();
            if (connection.State == System.Data.ConnectionState.Open)
            {
                string q = "SELECT * FROM ausleihe";
                DateTime dateTime;
                SqlCommand cmd = new SqlCommand(q, connection);
                cmd.ExecuteNonQuery();
                cmd.CommandType = System.Data.CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    dateTime = DateTime.Parse(rdr[2].ToString());
                    lent.Add(new Ausleihe(rdr[0].ToString(), rdr[1].ToString(), dateTime));
                }
            }
            return lent;
        }
    }
}
