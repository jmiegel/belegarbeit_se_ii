﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bibliothek_SE
{
    public partial class Form1 : Form
    {

        DataBConnection newConnection = new DataBConnection();
        public Form1()
        {
            InitializeComponent();
            listView1.View = View.Details;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        //Nach Entwurf
        private void buttonNutzerID_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBoxNutzerID.Text))
                MessageBox.Show("Bitte geben Sie eine NutzerID ein.", "NutzerID nötig!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            listView1.Items.Clear();
            List<String> signaturList = new List<string>();
            List<String> lentBooksTitleList = new List<string>();

            foreach (var lentItem in newConnection.getLentFromData()) {
                if (textBoxNutzerID.Text.Equals(lentItem.Nutzer_ID))
                {
                    foreach (var bookItem in newConnection.getBooksFromData()){
                        if (lentItem.Signatur_ID == bookItem.Signatur_ID)
                            listView1.Items.Add(new ListViewItem(new string[] { bookItem.Signatur_ID, bookItem.Titel, bookItem.Autor, lentItem.Datum.ToString() }));
                    }
                }
            }
            
            if (listView1.Items.Count == 0 && !string.IsNullOrWhiteSpace(textBoxNutzerID.Text))
                MessageBox.Show("Keine Einträge gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
        }

        //Nach Entwurf
        private void buttonSignatur_Click(object sender, EventArgs e)
        {
            bool gefunden = false;
            if (string.IsNullOrWhiteSpace(textBoxSignatur.Text))
            {
                MessageBox.Show("Bitte geben Sie eine Signatur ein.","Signatur fehlt!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else
            {
                foreach (var item in newConnection.getBooksFromData())
                {
                    if (textBoxSignatur.Text.Equals(item.Signatur_ID))
                    {
                        labelAutorAuswahl.Text = item.Autor.ToString();
                        labelTitelAuswahl.Text = item.Titel.ToString();
                        gefunden = true;
                    }
                }
                if (gefunden == false)
                    MessageBox.Show("Keine Einträge gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
        }

        private void buttonAusleihen_Click(object sender, EventArgs e)
        {
            /*string mahnung = "0";
            string vorgemerkt = "0";
            string exTyp = "0";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string getMahnung = "SELECT nutzerid, mahnung from bibliotheksNutzer where nutzerid='" + textBoxNutzerID.Text + "'";
            SqlCommand cmd = new SqlCommand(getMahnung, connection);
            cmd.ExecuteNonQuery();
            cmd.CommandType = System.Data.CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                if (textBoxNutzerID.Text.Equals(rdr[0].ToString()))
                {
                    mahnung = rdr[1].ToString();
                    break;
                }
            }
            rdr.Close();
            string getBuchinfo = "SELECT signatur, exTyp ,vorgemerkt from bibliotheksBuch where signatur='" + textBoxSignatur.Text + "'";
            cmd = new SqlCommand(getBuchinfo, connection);
            cmd.ExecuteNonQuery();
            cmd.CommandType = System.Data.CommandType.Text;
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                if (textBoxSignatur.Text.Equals(rdr[0].ToString()))
                {
                    exTyp = rdr[1].ToString();
                    vorgemerkt = rdr[2].ToString();
                    break;
                }
            }
            rdr.Close();
            if (string.IsNullOrWhiteSpace(textBoxSignatur.Text) || (string.IsNullOrWhiteSpace(textBoxNutzerID.Text) ))
            {
                MessageBox.Show("Bitte geben Sie eine NutzerID und eine Signatur ein.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else if (mahnung.Equals("1"))
            {
                MessageBox.Show("Dieser Nutzer darf keine Bücher ausleihen: Warnung vorhanden.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else if (vorgemerkt.Equals("1"))
            {
                MessageBox.Show("Dieses Buch ist vorgemerkt.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (exTyp.Equals("1"))
            {
                MessageBox.Show("Dieses Buch ist ein exemplar Typ und somit nicht zum Ausleihen verfügbar.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                DateTime thisDay = DateTime.Now;
                string rueckgabe = thisDay.AddDays(28).ToString();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    string ausleihe = "INSERT INTO ausleihe (nutzerid, signatur, rückgabeDatum) VALUES ('" + textBoxNutzerID.Text + "', " + "'" + textBoxSignatur.Text +"', " + "'" + rueckgabe + "')";
                    cmd = new SqlCommand(ausleihe, connection);
                    cmd.ExecuteNonQuery();
                    cmd.CommandType = System.Data.CommandType.Text;
                }
                MessageBox.Show("Buch erfolgreich ausgeliehen.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                buttonNutzerID_Click(sender, e); 
            }*/

        }

        private void buttonRueckgabe_Click(object sender, EventArgs e)
        {
            /*SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            int i = 0;
            if (listView1.Items.Count == 0)
            {
                MessageBox.Show("Kein Eintrag ausgewählt/gefunden.", "Zurückgeben fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                for (i = 0; i < listView1.Items.Count; i++)
                {
                    if (listView1.Items[i].Checked == true)
                    {
                        string getBookDetails = "DELETE FROM ausleihe WHERE signatur ='" + listView1.Items[i].Text + "'";
                        SqlCommand cmd = new SqlCommand(getBookDetails, connection);
                        cmd.ExecuteNonQuery();
                        cmd.CommandType = System.Data.CommandType.Text;
                    }
                }
                MessageBox.Show("Einträge erfolgreich gelöscht.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                buttonNutzerID_Click(sender, e);
            }*/

        }

        private void buttonVerlaengern_Click(object sender, EventArgs e)
        {
            /*if (listView1.Items.Count == 0)
            {
                MessageBox.Show("Kein Eintrag ausgewählt/gefunden.", "Verlängern fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                int i = 0;
                DateTime thisDay = DateTime.Now;
                string rueckgabe = thisDay.AddDays(14).ToString();
                for (i = 0; i < listView1.Items.Count; i++)
                {
                    if (listView1.Items[i].Checked == true)
                    {
                        string getBookDetails = "UPDATE ausleihe SET rückgabeDatum ='" + rueckgabe + "' where signatur='" + listView1.Items[i].Text + "'";
                        SqlCommand cmd = new SqlCommand(getBookDetails, connection);
                        cmd.ExecuteNonQuery();
                        cmd.CommandType = System.Data.CommandType.Text;
                    }
                }
                MessageBox.Show("Einträge erfolgreich verlängert.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                buttonNutzerID_Click(sender, e);
            }*/
        }
    }
}
