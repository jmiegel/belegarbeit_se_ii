﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bibliothek_SE
{
    public partial class Form1 : Form
    {
        public string connectionString = "Data Source=idb45;Initial Catalog=ii16s75905;Integrated Security=True";

        List<Nutzer> user = new List<Nutzer>();
        public Form1()
        {
            InitializeComponent();
            listView1.View = View.Details;
            /*listView1.Columns.Add("Signatur");
            listView1.Columns.Add("Titel");
            listView1.Columns.Add("Autor");
            listView1.Columns.Add("Rückgabe Datum");
            for (int i = 0; i < listView1.Columns.Count; i++ )
                listView1.Columns[i].Width = -2;*/
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBox2.Text))
                MessageBox.Show("Bitte geben Sie eine NutzerID ein.", "NutzerID nötig!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            listView1.Items.Clear();
            List<String> signaturList = new List<string>();
            List<String> lentBooksTitleList = new List<string>();
            //DataBConnection newDB = new DataBConnection();
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            if (connection.State == System.Data.ConnectionState.Open)
            {
                string q = "SELECT b.signatur, titel, autor, rückgabeDatum FROM bibliotheksBuch b, ausleihe a WHERE b.signatur = a.signatur and nutzerid ='" + textBox2.Text+"'";
                SqlCommand cmd = new SqlCommand(q, connection);
                cmd.ExecuteNonQuery();
                cmd.CommandType = System.Data.CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    listView1.Items.Add(new ListViewItem(new string[]{rdr[0].ToString(), rdr[1].ToString(), rdr[2].ToString(), rdr[3].ToString()}));
                }
            if (listView1.Items.Count == 0)
                MessageBox.Show("Keine Einträge gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Bitte geben Sie eine Signatur ein.","Signatur fehlt!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else{
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    bool gefunden = false;
                    string getBookDetails = "SELECT signatur, titel, autor FROM bibliotheksBuch WHERE signatur='" + textBox1.Text + "'";
                    SqlCommand cmd = new SqlCommand(getBookDetails, connection);
                    cmd.ExecuteNonQuery();
                    cmd.CommandType = System.Data.CommandType.Text;
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        if (textBox1.Text.Equals(rdr[0].ToString()))
                        {
                            label6.Text = rdr[1].ToString();
                            label7.Text = rdr[2].ToString();

                            label6.Invalidate();
                            label6.Update();

                            label7.Invalidate();
                            label7.Update();
                            gefunden = true;
                        }
                    }
                    if (gefunden == false)
                        MessageBox.Show("Keine Einträge gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || (string.IsNullOrWhiteSpace(textBox2.Text)))
            {
                MessageBox.Show("Bitte geben Sie eine NutzerID und eine Signatur ein.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else
            {
                DateTime thisDay = DateTime.Now;
                string rueckgabe = thisDay.AddDays(14).ToString();
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    string ausleihe = "INSERT INTO ausleihe (nutzerid, signatur, rückgabeDatum) VALUES ('" + textBox2.Text + "', " + "'" + textBox1.Text +"', " + "'" + rueckgabe + "')";
                    SqlCommand cmd = new SqlCommand(ausleihe, connection);
                    cmd.ExecuteNonQuery();
                    cmd.CommandType = System.Data.CommandType.Text;
                }
                MessageBox.Show("Buch erfolgreich ausgeliehen.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                button5_Click(sender, e); 
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            int i = 0;
            for (i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Checked == true)
                {
                    string getBookDetails = "DELETE FROM ausleihe WHERE signatur ='" + listView1.Items[i].Text + "'";
                    SqlCommand cmd = new SqlCommand(getBookDetails, connection);
                    cmd.ExecuteNonQuery();
                    cmd.CommandType = System.Data.CommandType.Text;
                }
            }
             MessageBox.Show("Einträge erfolgreich gelöscht.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
             button5_Click(sender, e); 


        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            int i = 0;
            DateTime thisDay = DateTime.Now;
            string rueckgabe = thisDay.AddDays(14).ToString();
            for (i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Checked == true)
                {
                    string getBookDetails = "UPDATE ausleihe SET rückgabeDatum ='" + rueckgabe + "' where signatur='"+ listView1.Items[i].Text + "'";
                    SqlCommand cmd = new SqlCommand(getBookDetails, connection);
                    cmd.ExecuteNonQuery();
                    cmd.CommandType = System.Data.CommandType.Text;
                }
            }
            MessageBox.Show("Einträge erfolgreich verlängert.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            button5_Click(sender, e); 
        }
    }
}
