﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bibliothek_SE
{
    public partial class Form1 : Form
    {
        public string connectionString = "Data Source=idb45;Initial Catalog=ii16s75899;Integrated Security=True";

        List<Nutzer> user = new List<Nutzer>();
        public Form1()
        {
            InitializeComponent();
            listView1.View = View.Details;
            /*listView1.Columns.Add("Signatur");
            listView1.Columns.Add("Titel");
            listView1.Columns.Add("Autor");
            listView1.Columns.Add("Rückgabe Datum");
            for (int i = 0; i < listView1.Columns.Count; i++ )
                listView1.Columns[i].Width = -2;*/
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonNutzerID_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBoxNutzerID.Text))
                MessageBox.Show("Bitte geben Sie eine NutzerID ein.", "NutzerID nötig!", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            listView1.Items.Clear();
            List<String> signaturList = new List<string>();
            List<String> lentBooksTitleList = new List<string>();
            //DataBConnection newDB = new DataBConnection();
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            if (connection.State == System.Data.ConnectionState.Open)
            {
                string q = "SELECT b.signatur, titel, autor, rückgabeDatum FROM bibliotheksBuch b, ausleihe a WHERE b.signatur = a.signatur and nutzerid ='" + textBoxNutzerID.Text+"'";
                SqlCommand cmd = new SqlCommand(q, connection);
                cmd.ExecuteNonQuery();
                cmd.CommandType = System.Data.CommandType.Text;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    listView1.Items.Add(new ListViewItem(new string[]{rdr[0].ToString(), rdr[1].ToString(), rdr[2].ToString(), rdr[3].ToString()}));
                }
                if (listView1.Items.Count == 0 && !string.IsNullOrWhiteSpace(textBoxNutzerID.Text))
                MessageBox.Show("Keine Einträge gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
        }

        private void buttonSignatur_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxSignatur.Text))
            {
                MessageBox.Show("Bitte geben Sie eine Signatur ein.","Signatur fehlt!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else{
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    bool gefunden = false;
                    string getBookDetails = "SELECT signatur, titel, autor FROM bibliotheksBuch WHERE signatur='" + textBoxSignatur.Text + "'";
                    SqlCommand cmd = new SqlCommand(getBookDetails, connection);
                    cmd.ExecuteNonQuery();
                    cmd.CommandType = System.Data.CommandType.Text;
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        if (textBoxSignatur.Text.Equals(rdr[0].ToString()))
                        {
                            labelAutorAuswahl.Text = rdr[1].ToString();
                            labelTitelAuswahl.Text = rdr[2].ToString();

                            labelAutorAuswahl.Invalidate();
                            labelAutorAuswahl.Update();

                            labelTitelAuswahl.Invalidate();
                            labelTitelAuswahl.Update();
                            gefunden = true;
                        }
                    }
                    if (gefunden == false)
                        MessageBox.Show("Keine Einträge gefunden.", "Suche abgeschlossen!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                }
            }
        }

        private void buttonAusleihen_Click(object sender, EventArgs e)
        {
            string mahnung = "0";
            string vorgemerkt = "0";
            string exTyp = "0";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            string getMahnung = "SELECT nutzerid, mahnung from bibliotheksNutzer where nutzerid='" + textBoxNutzerID.Text + "'";
            SqlCommand cmd = new SqlCommand(getMahnung, connection);
            cmd.ExecuteNonQuery();
            cmd.CommandType = System.Data.CommandType.Text;
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                if (textBoxNutzerID.Text.Equals(rdr[0].ToString()))
                {
                    mahnung = rdr[1].ToString();
                    break;
                }
            }
            rdr.Close();
            string getBuchinfo = "SELECT signatur, exTyp ,vorgemerkt from bibliotheksBuch where signatur='" + textBoxSignatur.Text + "'";
            cmd = new SqlCommand(getBuchinfo, connection);
            cmd.ExecuteNonQuery();
            cmd.CommandType = System.Data.CommandType.Text;
            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                if (textBoxSignatur.Text.Equals(rdr[0].ToString()))
                {
                    exTyp = rdr[1].ToString();
                    vorgemerkt = rdr[2].ToString();
                    break;
                }
            }
            rdr.Close();
            if (string.IsNullOrWhiteSpace(textBoxSignatur.Text) || (string.IsNullOrWhiteSpace(textBoxNutzerID.Text) ))
            {
                MessageBox.Show("Bitte geben Sie eine NutzerID und eine Signatur ein.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else if (mahnung.Equals("1"))
            {
                MessageBox.Show("Dieser Nutzer darf keine Bücher ausleihen: Warnung vorhanden.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
            else if (vorgemerkt.Equals("1"))
            {
                MessageBox.Show("Dieses Buch ist vorgemerkt.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (exTyp.Equals("1"))
            {
                MessageBox.Show("Dieses Buch ist ein exemplar Typ und somit nicht zum Ausleihen verfügbar.", "Ausleihen fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                DateTime thisDay = DateTime.Now;
                string rueckgabe = thisDay.AddDays(14).ToString();

                if (connection.State == System.Data.ConnectionState.Open)
                {
                    string ausleihe = "INSERT INTO ausleihe (nutzerid, signatur, rückgabeDatum) VALUES ('" + textBoxNutzerID.Text + "', " + "'" + textBoxSignatur.Text +"', " + "'" + rueckgabe + "')";
                    cmd = new SqlCommand(ausleihe, connection);
                    cmd.ExecuteNonQuery();
                    cmd.CommandType = System.Data.CommandType.Text;
                }
                MessageBox.Show("Buch erfolgreich ausgeliehen.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                buttonNutzerID_Click(sender, e); 
            }

        }

        private void buttonRueckgabe_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            int i = 0;
            if (listView1.Items.Count == 0)
            {
                MessageBox.Show("Kein Eintrag ausgewählt/gefunden.", "Zurückgeben fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                for (i = 0; i < listView1.Items.Count; i++)
                {
                    if (listView1.Items[i].Checked == true)
                    {
                        string getBookDetails = "DELETE FROM ausleihe WHERE signatur ='" + listView1.Items[i].Text + "'";
                        SqlCommand cmd = new SqlCommand(getBookDetails, connection);
                        cmd.ExecuteNonQuery();
                        cmd.CommandType = System.Data.CommandType.Text;
                    }
                }
                MessageBox.Show("Einträge erfolgreich gelöscht.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                buttonNutzerID_Click(sender, e);
            }

        }

        private void buttonVerlaengern_Click(object sender, EventArgs e)
        {
            if (listView1.Items.Count == 0)
            {
                MessageBox.Show("Kein Eintrag ausgewählt/gefunden.", "Verlängern fehlgeschlagen!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                int i = 0;
                DateTime thisDay = DateTime.Now;
                string rueckgabe = thisDay.AddDays(14).ToString();
                for (i = 0; i < listView1.Items.Count; i++)
                {
                    if (listView1.Items[i].Checked == true)
                    {
                        string getBookDetails = "UPDATE ausleihe SET rückgabeDatum ='" + rueckgabe + "' where signatur='" + listView1.Items[i].Text + "'";
                        SqlCommand cmd = new SqlCommand(getBookDetails, connection);
                        cmd.ExecuteNonQuery();
                        cmd.CommandType = System.Data.CommandType.Text;
                    }
                }
                MessageBox.Show("Einträge erfolgreich verlängert.", " Erfolg!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                buttonNutzerID_Click(sender, e);
            }
        }
    }
}
