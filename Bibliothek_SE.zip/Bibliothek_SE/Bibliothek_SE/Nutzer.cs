﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibliothek_SE
{
    class Nutzer
    {
        public string Nutzer_ID     //Nutzer_ID nötig um Nutzer eindeutig zu identifizieren
        {
            get;
            private set;
        }
    }
}
