﻿namespace Bibliothek_SE
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRueckgabe = new System.Windows.Forms.Button();
            this.buttonVerlaengern = new System.Windows.Forms.Button();
            this.labelNutzerID = new System.Windows.Forms.Label();
            this.buttonAusleihen = new System.Windows.Forms.Button();
            this.buttonNutzerID = new System.Windows.Forms.Button();
            this.labelAutor = new System.Windows.Forms.Label();
            this.labelSignatur = new System.Windows.Forms.Label();
            this.labelTitel = new System.Windows.Forms.Label();
            this.textBoxNutzerID = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonSignatur = new System.Windows.Forms.Button();
            this.textBoxSignatur = new System.Windows.Forms.TextBox();
            this.labelTitelAuswahl = new System.Windows.Forms.Label();
            this.labelAutorAuswahl = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.buttonRueckgabe.Location = new System.Drawing.Point(270, 454);
            this.buttonRueckgabe.Name = "button1";
            this.buttonRueckgabe.Size = new System.Drawing.Size(177, 23);
            this.buttonRueckgabe.TabIndex = 0;
            this.buttonRueckgabe.Text = "Zurückgeben";
            this.buttonRueckgabe.UseVisualStyleBackColor = true;
            this.buttonRueckgabe.Click += new System.EventHandler(this.buttonRueckgabe_Click);
            // 
            // button2
            // 
            this.buttonVerlaengern.Location = new System.Drawing.Point(453, 454);
            this.buttonVerlaengern.Name = "button2";
            this.buttonVerlaengern.Size = new System.Drawing.Size(178, 23);
            this.buttonVerlaengern.TabIndex = 1;
            this.buttonVerlaengern.Text = "Verlängern";
            this.buttonVerlaengern.UseVisualStyleBackColor = true;
            this.buttonVerlaengern.Click += new System.EventHandler(this.buttonVerlaengern_Click);
            // 
            // label1
            // 
            this.labelNutzerID.AutoSize = true;
            this.labelNutzerID.Location = new System.Drawing.Point(13, 38);
            this.labelNutzerID.Name = "label1";
            this.labelNutzerID.Size = new System.Drawing.Size(49, 13);
            this.labelNutzerID.TabIndex = 2;
            this.labelNutzerID.Text = "NutzerID";
            // 
            // button4
            // 
            this.buttonAusleihen.Location = new System.Drawing.Point(24, 454);
            this.buttonAusleihen.Name = "button4";
            this.buttonAusleihen.Size = new System.Drawing.Size(177, 23);
            this.buttonAusleihen.TabIndex = 10;
            this.buttonAusleihen.Text = "Ausleihen";
            this.buttonAusleihen.UseVisualStyleBackColor = true;
            this.buttonAusleihen.Click += new System.EventHandler(this.buttonAusleihen_Click);
            // 
            // button5
            // 
            this.buttonNutzerID.Location = new System.Drawing.Point(153, 79);
            this.buttonNutzerID.Name = "button5";
            this.buttonNutzerID.Size = new System.Drawing.Size(108, 22);
            this.buttonNutzerID.TabIndex = 13;
            this.buttonNutzerID.Text = "Auswählen";
            this.buttonNutzerID.UseVisualStyleBackColor = true;
            this.buttonNutzerID.Click += new System.EventHandler(this.buttonNutzerID_Click);
            // 
            // label2
            // 
            this.labelAutor.AutoSize = true;
            this.labelAutor.Location = new System.Drawing.Point(19, 38);
            this.labelAutor.Name = "label2";
            this.labelAutor.Size = new System.Drawing.Size(32, 13);
            this.labelAutor.TabIndex = 14;
            this.labelAutor.Text = "Autor";
            // 
            // label3
            // 
            this.labelSignatur.AutoSize = true;
            this.labelSignatur.Location = new System.Drawing.Point(17, 9);
            this.labelSignatur.Name = "label3";
            this.labelSignatur.Size = new System.Drawing.Size(46, 13);
            this.labelSignatur.TabIndex = 15;
            this.labelSignatur.Text = "Signatur";
            // 
            // label4
            // 
            this.labelTitel.AutoSize = true;
            this.labelTitel.Location = new System.Drawing.Point(19, 65);
            this.labelTitel.Name = "label4";
            this.labelTitel.Size = new System.Drawing.Size(27, 13);
            this.labelTitel.TabIndex = 16;
            this.labelTitel.Text = "Titel";
            // 
            // textBox2
            // 
            this.textBoxNutzerID.Location = new System.Drawing.Point(79, 38);
            this.textBoxNutzerID.Name = "textBoxNutzerID";
            this.textBoxNutzerID.Size = new System.Drawing.Size(100, 20);
            this.textBoxNutzerID.TabIndex = 17;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.buttonSignatur);
            this.panel1.Controls.Add(this.textBoxSignatur);
            this.panel1.Controls.Add(this.labelTitelAuswahl);
            this.panel1.Controls.Add(this.labelAutorAuswahl);
            this.panel1.Controls.Add(this.labelSignatur);
            this.panel1.Controls.Add(this.labelAutor);
            this.panel1.Controls.Add(this.labelTitel);
            this.panel1.Location = new System.Drawing.Point(330, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(300, 105);
            this.panel1.TabIndex = 18;
            // 
            // button3
            // 
            this.buttonSignatur.Location = new System.Drawing.Point(189, 78);
            this.buttonSignatur.Name = "button3";
            this.buttonSignatur.Size = new System.Drawing.Size(108, 23);
            this.buttonSignatur.TabIndex = 21;
            this.buttonSignatur.Text = "Auswählen";
            this.buttonSignatur.UseVisualStyleBackColor = true;
            this.buttonSignatur.Click += new System.EventHandler(this.buttonSignatur_Click);
            // 
            // textBox1
            // 
            this.textBoxSignatur.Location = new System.Drawing.Point(69, 6);
            this.textBoxSignatur.Name = "textBoxSignatur";
            this.textBoxSignatur.Size = new System.Drawing.Size(100, 20);
            this.textBoxSignatur.TabIndex = 20;
            // 
            // label7
            // 
            this.labelTitelAuswahl.AutoSize = true;
            this.labelTitelAuswahl.Location = new System.Drawing.Point(66, 65);
            this.labelTitelAuswahl.Name = "label7";
            this.labelTitelAuswahl.Size = new System.Drawing.Size(39, 13);
            this.labelTitelAuswahl.TabIndex = 19;
            this.labelTitelAuswahl.Text = "<Titel>";
            // 
            // label6
            // 
            this.labelAutorAuswahl.AutoSize = true;
            this.labelAutorAuswahl.Location = new System.Drawing.Point(66, 38);
            this.labelAutorAuswahl.Name = "label6";
            this.labelAutorAuswahl.Size = new System.Drawing.Size(44, 13);
            this.labelAutorAuswahl.TabIndex = 18;
            this.labelAutorAuswahl.Text = "<Autor>";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttonNutzerID);
            this.panel2.Controls.Add(this.textBoxNutzerID);
            this.panel2.Controls.Add(this.labelNutzerID);
            this.panel2.Location = new System.Drawing.Point(22, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(264, 105);
            this.panel2.TabIndex = 19;
            // 
            // listView1
            // 
            this.listView1.CheckBoxes = true;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(22, 120);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(605, 328);
            this.listView1.TabIndex = 20;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Signatur";
            this.columnHeader1.Width = 95;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Titel";
            this.columnHeader2.Width = 205;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Autor";
            this.columnHeader3.Width = 152;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Rückgabe Datum";
            this.columnHeader4.Width = 147;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 485);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonAusleihen);
            this.Controls.Add(this.buttonVerlaengern);
            this.Controls.Add(this.buttonRueckgabe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Bibliothek Ausleihe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonRueckgabe;
        private System.Windows.Forms.Button buttonVerlaengern;
        private System.Windows.Forms.Label labelNutzerID;
        private System.Windows.Forms.Button buttonAusleihen;
        private System.Windows.Forms.Button buttonNutzerID;
        private System.Windows.Forms.Label labelAutor;
        private System.Windows.Forms.Label labelSignatur;
        private System.Windows.Forms.Label labelTitel;
        private System.Windows.Forms.TextBox textBoxNutzerID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxSignatur;
        private System.Windows.Forms.Label labelTitelAuswahl;
        private System.Windows.Forms.Label labelAutorAuswahl;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttonSignatur;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
    }
}

